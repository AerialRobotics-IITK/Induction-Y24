#include <iostream>
#include <vector>
#include <fstream>
#include <sstream>
#include <algorithm>
#include <limits>  

using namespace std;

struct User {
    string username;
    string password;
    vector<string> rented;
    vector<string> owned;
    int dues;

    User() : dues(0) {}
};

class MediaCatalog {
public:
    vector<string> movies;
    vector<string> shows;

    MediaCatalog() {
        string tempMovies[] = {
            "The Shawshank Redemption", "The Godfather", "The Dark Knight", "Pulp Fiction", "Inception",
            "Fight Club", "Forrest Gump", "The Matrix", "The Lion King", "Gladiator",
            "Titanic", "Goodfellas", "Interstellar", "The Silence of the Lambs", "The Green Mile",
            "Saving Private Ryan", "Avengers Endgame", "The Lord of the Rings", "The Departed", "Coco",
            "Parasite", "Whiplash", "Joker", "Up", "The_Prestige",
            "The Pianist", "Shutter Island", "Black Panther", "Iron Man", "Captain Marvel",
            "Doctor Strange", "Frozen", "Finding Nemo", "Toy Story", "Soul",
            "La La Land", "Knives Out", "Logan", "1917", "Dunkirk", "The Revenant",
            "Zootopia", "Inside Out", "Tenet", "No Time to Die", "Oppenheimer",
            "Dune", "Everything Everywhere All At Once", "John Wick", "Spider Man", "The Batman"
        };
        for (int i = 0; i < 50; ++i) movies.push_back(tempMovies[i]);

        string tempShows[] = {
            "Breaking Bad", "Game of Thrones", "Stranger Things", "The Office", "Friends",
            "Peaky Blinders", "Money Heist", "Narcos", "Better Call Saul", "The Boys",
            "Dark", "Chernobyl", "The Mandalorian", "The Witcher", "Loki",
            "House of the Dragon", "Wednesday", "The Crown", "The Last of Us", "Sherlock",
            "Brooklyn Nine Nine", "How I Met Your Mother", "Rick and Morty", "The Queen's Gambit", "Manifest",
            "Lost", "Prison Break", "Dexter", "Lucifer", "The_100",
            "Blacklist", "Suits", "The Expanse", "Vikings", "The Walking Dead",
            "The Good Doctor", "Grey's Anatomy", "The Flash", "Arrow", "Supernatural",
            "Modern Family", "The Big Bang Theory", "Young Sheldon", "Severance", "True Detective",
            "The Night Agent", "Upload", "Invincible", "The Morning Show", "Silicon Valley"
        };
        for (int i = 0; i < 50; ++i) shows.push_back(tempShows[i]);
    }

    void displayCatalog() {
        cout << "\n--- Movies ---\n";
        for (size_t i = 0; i < movies.size(); ++i) cout << movies[i] << endl;

        cout << "\n--- TV Shows ---\n";
        for (size_t i = 0; i < shows.size(); ++i) cout << shows[i] << endl;
    }

    bool contentExists(const string& title) {
        return (find(movies.begin(), movies.end(), title) != movies.end() ||
                find(shows.begin(), shows.end(), title) != shows.end());
    }

    void addContent(bool isMovie, const string& title) {
        vector<string>& list = isMovie ? movies : shows;
        if (find(list.begin(), list.end(), title) == list.end()) {
            list.push_back(title);
            cout << (isMovie ? "Movie" : "Show") << " added successfully.\n";
        } else {
            cout << "Content already exists.\n";
        }
    }

    void removeContent(bool isMovie, const string& title) {
        vector<string>& list = isMovie ? movies : shows;
        vector<string>::iterator it = find(list.begin(), list.end(), title);
        if (it != list.end()) {
            list.erase(it);
            cout << (isMovie ? "Movie" : "Show") << " removed.\n";
        } else {
            cout << "Content not found.\n";
        }
    }
};




vector<User> loadUsers() {
    vector<User> users;
    ifstream file("userdata.txt");
    if (!file.is_open()) {
        cout << "Error: Could not open userdata.txt for reading.\n";
        return users; 
    }

    string line;
    while (getline(file, line)) {
        stringstream ss(line);
        User u;
        string rented, owned;
        getline(ss, u.username, ',');
        getline(ss, u.password, ',');
        ss >> u.dues; ss.ignore();

        getline(ss, rented, ',');
        stringstream rs(rented);
        string item;
        while (getline(rs, item, '|')) u.rented.push_back(item);

        getline(ss, owned);
        stringstream os(owned);
        while (getline(os, item, '|')) u.owned.push_back(item);

        users.push_back(u);
    }
    return users;
}


void saveUsers(const vector<User>& users) {
    ofstream file("userdata.txt", ios::trunc);
    if (!file.is_open()) {
        cout << "Error: Could not open userdata.txt for writing.\n";
        return;
    }

    for (size_t i = 0; i < users.size(); ++i) {
        const User& u = users[i];
        file << u.username << "," << u.password << "," << u.dues << ",";

        for (size_t j = 0; j < u.rented.size(); ++j) {
            file << u.rented[j];
            if (j + 1 < u.rented.size()) file << "|";
        }
        file << ",";

        for (size_t j = 0; j < u.owned.size(); ++j) {
            file << u.owned[j];
            if (j + 1 < u.owned.size()) file << "|";
        }
        file << "\n";
    }
}


void userPanel(User& user, MediaCatalog& catalog) {
    while (true) {
        cout << "\nUser Menu\n1. Browse Catalog\n2. Rent Content\n3. Buy Content\n4. View Rentals\n5. View Purchases\n6. Pay Dues\n7. Return Content\n0. Logout\nChoose: ";
        int choice;
        cin >> choice;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        string title;
        if (choice == 0) break;

        switch (choice) {
        case 1:
            catalog.displayCatalog();
            break;
        case 2:
            cout << "Enter content to rent: ";
            getline(cin, title);
            if (catalog.contentExists(title)) {
                user.rented.push_back(title);
                user.dues += 120;
                cout << "Rented. Dues: ₹" << user.dues << endl;
            } else cout << "Not found.\n";
            break;
        case 3:
            cout << "Enter content to buy: ";
            getline(cin, title);
            if (catalog.contentExists(title)) {
                user.owned.push_back(title);
                cout << "Purchased.\n";
            } else cout << "Not found.\n";
            break;
        case 4:
            cout << "Your Rentals:\n";
            for (size_t i = 0; i < user.rented.size(); ++i)
                cout << user.rented[i] << endl;
            break;
        case 5:
            cout << "Your Purchases:\n";
            for (size_t i = 0; i < user.owned.size(); ++i)
                cout << user.owned[i] << endl;
            break;
        case 6:
            cout << "Dues: ₹" << user.dues << ". Pay? (yes/no): ";
            getline(cin, title);
            if (title == "yes") {
                user.dues = 0;
                cout << "Dues cleared.\n";
            }
            break;
        case 7:
            cout << "Enter content to return: ";
            getline(cin, title);
            {
                vector<string>::iterator it = find(user.rented.begin(), user.rented.end(), title);
                if (it != user.rented.end()) {
                    user.rented.erase(it);
                    cout << "Returned.\n";
                } else cout << "Not in rentals.\n";
            }
            break;
        }
    }
}


void adminPanel(MediaCatalog& catalog) {
    while (true) {
        cout << "\nAdmin Menu\n1. View Catalog\n2. Add Movie\n3. Add Show\n4. Remove Movie\n5. Remove Show\n0. Logout\nChoose: ";
        int choice;
        cin >> choice;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        string title;
        if (choice == 0) break;

        switch (choice) {
        case 1:
            catalog.displayCatalog();
            break;
        case 2:
            cout << "Enter movie to add: ";
            getline(cin, title);
            catalog.addContent(true, title);
            break;
        case 3:
            cout << "Enter show to add: ";
            getline(cin, title);
            catalog.addContent(false, title);
            break;
        case 4:
            cout << "Enter movie to remove: ";
            getline(cin, title);
            catalog.removeContent(true, title);
            break;
        case 5:
            cout << "Enter show to remove: ";
            getline(cin, title);
            catalog.removeContent(false, title);
            break;
        }
    }
}

// Main function
int main() {
    vector<User> users = loadUsers();
    MediaCatalog catalog;

    while (true) {
        cout << "\nWelcome to OTT Platform\n1. Login\n2. Register\n3. Admin Login\n0. Exit\nChoose: ";
        int action;
        cin >> action;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        if (action == 0) break;

        string uname, pass;
        cout << "Username: ";
        getline(cin, uname);
        cout << "Password: ";
        getline(cin, pass);

        if (action == 1) {
            bool found = false;
            for (size_t i = 0; i < users.size(); ++i) {
                if (users[i].username == uname && users[i].password == pass) {
                    userPanel(users[i], catalog);
                    found = true;
                    break;
                }
            }
            if (!found) cout << "Invalid credentials.\n";
        } else if (action == 2) {
            bool exists = false;
            for (size_t i = 0; i < users.size(); ++i) {
                if (users[i].username == uname) {
                    exists = true;
                    break;
                }
            }
            if (exists) cout << "Username exists.\n";
            else {
                User u;
                u.username = uname;
                u.password = pass;
                users.push_back(u);
                cout << "Registered. Please log in.\n";
                saveUsers(users);  
            }
        } else if (action == 3) {
            if (uname == "admin" && pass == "admin123")
                adminPanel(catalog);
            else
                cout << "Invalid admin credentials.\n";
        }
    }

    saveUsers(users);  
    cout << "Goodbye!\n";
    return 0;
}